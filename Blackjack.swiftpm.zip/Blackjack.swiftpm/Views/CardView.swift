import SwiftUI

/// A single playing card.
///
/// Renders the white face (rank + suit in opposite corners, big pip in the
/// middle) or the patterned blue back, and 3D-flips between them whenever
/// `card.isFaceUp` changes inside a `withAnimation` block.
struct CardView: View {
    let card: Card

    var body: some View {
        ZStack {
            front
                .opacity(card.isFaceUp ? 1 : 0)
            back
                .opacity(card.isFaceUp ? 0 : 1)
                // Pre-rotate the back 180° so it reads correctly once the
                // outer rotation below turns the whole card over.
                .rotation3DEffect(.degrees(180), axis: (x: 0, y: 1, z: 0))
        }
        // The actual flip: 0° face up, 180° face down. Animating this together
        // with the opacity swap above looks like a real card being turned.
        .rotation3DEffect(.degrees(card.isFaceUp ? 0 : 180), axis: (x: 0, y: 1, z: 0))
        .frame(width: Theme.cardSize.width, height: Theme.cardSize.height)
        .shadow(color: .black.opacity(0.35), radius: 4, x: 0, y: 3)
    }

    // MARK: Face

    private var front: some View {
        ZStack {
            RoundedRectangle(cornerRadius: Theme.cardCornerRadius)
                .fill(.white)

            // Big centre pip
            Text(card.suit.rawValue)
                .font(.system(size: 34))
                .foregroundStyle(card.suit.color)

            // Rank + suit in the corners; the bottom one is rotated 180°
            // like a real playing card.
            VStack {
                HStack {
                    cornerLabel
                    Spacer()
                }
                Spacer()
                HStack {
                    Spacer()
                    cornerLabel.rotationEffect(.degrees(180))
                }
            }
            .padding(5)
        }
    }

    private var cornerLabel: some View {
        VStack(spacing: -2) {
            Text(card.rank.label)
                .font(.system(size: 16, weight: .bold, design: .rounded))
            Text(card.suit.rawValue)
                .font(.system(size: 13))
        }
        .foregroundStyle(card.suit.color)
    }

    // MARK: Back

    /// White border around a blue panel filled with a diagonal lattice.
    private var back: some View {
        ZStack {
            RoundedRectangle(cornerRadius: Theme.cardCornerRadius)
                .fill(.white)

            RoundedRectangle(cornerRadius: Theme.cardCornerRadius - 3)
                .fill(Theme.cardBack)
                .overlay {
                    Canvas { context, size in
                        // Criss-crossing 45° lines make a diamond lattice.
                        let step: CGFloat = 9
                        var path = Path()
                        var x: CGFloat = -size.height
                        while x < size.width + size.height {
                            path.move(to: CGPoint(x: x, y: 0))
                            path.addLine(to: CGPoint(x: x + size.height, y: size.height))
                            path.move(to: CGPoint(x: x + size.height, y: 0))
                            path.addLine(to: CGPoint(x: x, y: size.height))
                            x += step
                        }
                        context.stroke(path, with: .color(.white.opacity(0.35)), lineWidth: 1)
                    }
                    .clipShape(RoundedRectangle(cornerRadius: Theme.cardCornerRadius - 3))
                }
                .padding(4)
        }
    }
}

#Preview("Card faces and back") {
    HStack(spacing: 12) {
        CardView(card: Card(suit: .hearts, rank: .ace))
        CardView(card: Card(suit: .spades, rank: .ten))
        CardView(card: Card(suit: .diamonds, rank: .queen, isFaceUp: false))
    }
    .padding()
    .background(Theme.felt)
}
