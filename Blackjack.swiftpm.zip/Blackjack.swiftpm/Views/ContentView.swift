import SwiftUI

/// The casino table, top to bottom:
///
///     ┌──────────────────────────────┐
///     │ ScoreboardView               │  bankroll · rounds · net
///     │ Dealer hand + score          │
///     │ Status message               │  "Hit or Stand?", "You Win! +$50"
///     │ BettingView (betting only)   │  chip rack
///     │ Player hand(s) + score       │  one hand, or two side by side
///     │ ControlsView                 │  Deal / Hit · Stand · Split / New Round
///     └──────────────────────────────┘
struct ContentView: View {
    @StateObject private var game = BlackjackViewModel()

    var body: some View {
        ZStack {
            Theme.felt.ignoresSafeArea()

            VStack(spacing: 0) {
                ScoreboardView(
                    bankroll: game.bankroll,
                    roundsPlayed: game.roundsPlayed,
                    netProfit: game.netSessionProfit
                )
                .padding(.top, 4)

                dealerArea
                    .padding(.top, 14)

                Spacer(minLength: 10)

                statusMessage

                if game.phase == .betting {
                    BettingView(
                        currentBet: game.currentBet,
                        bankroll: game.bankroll,
                        onChip: { game.addChip($0) },
                        onClear: { game.clearBet() }
                    )
                    .padding(.top, 18)
                    .transition(.scale(scale: 0.9).combined(with: .opacity))
                }

                Spacer(minLength: 10)

                playerArea

                ControlsView(game: game)
                    .padding(.top, 16)
                    .padding(.bottom, 8)
            }
            .padding(.horizontal)
        }
    }

    // MARK: Dealer

    private var dealerArea: some View {
        VStack(spacing: 12) {
            // While the hole card is hidden, show only the face-up total ("7 + ?").
            HandHeaderView(
                name: "DEALER",
                score: game.holeCardHidden ? "\(game.dealerVisibleScore) + ?" : "\(game.dealerScore)",
                showScore: !game.dealerHand.isEmpty
            )
            CardRowView(cards: game.dealerHand)
        }
    }

    // MARK: Status

    private var statusMessage: some View {
        Text(game.statusMessage)
            .font(.title2.weight(.bold))
            .foregroundStyle(.white)
            .multilineTextAlignment(.center)
            .padding(.horizontal, 26)
            .padding(.vertical, 12)
            .background(Capsule().fill(.black.opacity(0.25)))
            .overlay(Capsule().strokeBorder(Theme.gold.opacity(0.6), lineWidth: 1))
            // A new id per message makes SwiftUI treat it as a new view, so
            // the transition below runs on every status change.
            .id(game.statusMessage)
            .transition(.scale(scale: 0.8).combined(with: .opacity))
            .animation(.spring(response: 0.35, dampingFraction: 0.7), value: game.statusMessage)
    }

    // MARK: Player

    private var playerArea: some View {
        Group {
            if game.isSplit {
                // Two hands side by side; the active one is highlighted in gold.
                HStack(alignment: .bottom, spacing: 14) {
                    ForEach(Array(game.playerHands.enumerated()), id: \.element.id) { index, hand in
                        SplitHandView(
                            hand: hand,
                            index: index,
                            isActive: game.phase == .playerTurn && game.activeHandIndex == index
                        )
                    }
                }
            } else if let hand = game.playerHands.first {
                VStack(spacing: 12) {
                    CardRowView(cards: hand.cards)
                    HandHeaderView(name: "YOU", score: "\(hand.score)", bet: hand.bet)
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
