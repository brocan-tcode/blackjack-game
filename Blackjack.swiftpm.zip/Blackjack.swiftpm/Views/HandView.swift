import SwiftUI

// MARK: - Card row

/// A row of cards. New cards slide in from the trailing edge (the "shoe"),
/// and overlap more as the hand grows so a big hand still fits on screen.
struct CardRowView: View {
    let cards: [Card]
    /// Pass a tighter spacing when two split hands share the screen.
    var spacingOverride: CGFloat?

    var body: some View {
        HStack(spacing: spacingOverride ?? Self.overlapSpacing(for: cards.count)) {
            ForEach(cards) { card in
                CardView(card: card)
                    .transition(.asymmetric(
                        insertion: .move(edge: .trailing).combined(with: .opacity),
                        removal: .opacity
                    ))
            }
        }
        .frame(minHeight: Theme.cardSize.height)
    }

    static func overlapSpacing(for count: Int) -> CGFloat {
        switch count {
        case ..<4: return -14
        case 4:    return -26
        case 5:    return -34
        default:   return -42
        }
    }
}

// MARK: - Hand header

/// Gold name tag + score badge (+ optional bet) above or below a hand.
struct HandHeaderView: View {
    let name: String
    let score: String
    var showScore = true
    var bet: Int?

    var body: some View {
        HStack(spacing: 10) {
            Text(name)
                .font(.footnote.weight(.heavy))
                .tracking(2.5)
                .foregroundStyle(Theme.gold)
            ScoreBadge(text: score)
                .opacity(showScore ? 1 : 0)   // keep layout stable before the deal
            if let bet {
                Text("BET $\(bet)")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Theme.gold.opacity(0.9))
            }
        }
    }
}

struct ScoreBadge: View {
    let text: String

    var body: some View {
        Text(text)
            .font(.footnote.weight(.bold))
            .monospacedDigit()
            .foregroundStyle(.white)
            .padding(.horizontal, 10)
            .padding(.vertical, 3)
            .background(Capsule().fill(.black.opacity(0.35)))
    }
}

// MARK: - Split hand

/// One of the two hands after a split: cards, then HAND n · score · bet ·
/// outcome, boxed in gold while it is the hand being played.
struct SplitHandView: View {
    let hand: PlayerHand
    let index: Int
    let isActive: Bool

    var body: some View {
        VStack(spacing: 8) {
            CardRowView(cards: hand.cards,
                        spacingOverride: hand.cards.count <= 3 ? -38 : -50)
            HStack(spacing: 6) {
                Text("HAND \(index + 1)")
                    .font(.system(size: 10, weight: .heavy))
                    .tracking(1)
                    .foregroundStyle(isActive ? Theme.gold : .white.opacity(0.6))
                ScoreBadge(text: "\(hand.score)")
                Text("$\(hand.bet)")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(Theme.gold.opacity(0.9))
                if let outcome = hand.outcome {
                    Text(outcome.rawValue)
                        .font(.system(size: 10, weight: .heavy))
                        .foregroundStyle(outcome.isFavorable ? Theme.win : Theme.loss)
                }
            }
        }
        .padding(.vertical, 8)
        .padding(.horizontal, 6)
        .background(RoundedRectangle(cornerRadius: 12).fill(.black.opacity(isActive ? 0.28 : 0.10)))
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .strokeBorder(isActive ? Theme.gold : .clear, lineWidth: 2)
        )
        .transition(.scale(scale: 0.8).combined(with: .opacity))
    }
}

#Preview("Split hands") {
    HStack(alignment: .bottom, spacing: 14) {
        SplitHandView(
            hand: PlayerHand(cards: [Card(suit: .spades, rank: .eight),
                                     Card(suit: .hearts, rank: .king)],
                             bet: 50),
            index: 0,
            isActive: true
        )
        SplitHandView(
            hand: PlayerHand(cards: [Card(suit: .clubs, rank: .eight),
                                     Card(suit: .diamonds, rank: .three)],
                             bet: 50,
                             outcome: .win),
            index: 1,
            isActive: false
        )
    }
    .padding()
    .background(Theme.felt)
}
