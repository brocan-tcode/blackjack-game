import SwiftUI

/// A tappable casino chip: colored disc, dashed inner ring, denomination.
struct ChipView: View {
    let value: Int
    let isEnabled: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            ZStack {
                Circle()
                    .fill(Theme.chipColor(for: value))
                Circle()
                    .strokeBorder(Theme.chipRimColor(for: value).opacity(0.9),
                                  style: StrokeStyle(lineWidth: 2.5, dash: [7, 5]))
                    .padding(5)
                Text("\(value)")
                    .font(.system(size: value >= 100 ? 17 : 19, weight: .heavy, design: .rounded))
                    .foregroundStyle(Theme.chipInkColor(for: value))
            }
            .frame(width: 66, height: 66)
            .shadow(color: .black.opacity(0.35), radius: 3, y: 2)
        }
        .buttonStyle(.plain)
        .disabled(!isEnabled)
        .opacity(isEnabled ? 1 : 0.35)   // dim chips the bankroll can't cover
    }
}

#Preview("Chip rack") {
    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 12) {
        ForEach(BlackjackViewModel.chipValues, id: \.self) { value in
            ChipView(value: value, isEnabled: value <= 100) {}
        }
    }
    .padding()
    .background(Theme.felt)
}
