import SwiftUI

/// The betting interface, shown only during `.betting`: the bet being built,
/// the chip rack, and a Clear Bet link.
struct BettingView: View {
    let currentBet: Int
    let bankroll: Int
    let onChip: (Int) -> Void
    let onClear: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            VStack(spacing: 2) {
                Text("CURRENT BET")
                    .font(.system(size: 11, weight: .heavy))
                    .tracking(2)
                    .foregroundStyle(Theme.gold)
                Text("$\(currentBet.formatted())")
                    .font(.system(size: 42, weight: .heavy, design: .rounded))
                    .monospacedDigit()
                    .foregroundStyle(.white)
                    .contentTransition(.numericText())
            }

            // Chip rack — two rows of three. A chip dims out once the bankroll
            // can no longer cover adding it to the current bet.
            LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 12) {
                ForEach(BlackjackViewModel.chipValues, id: \.self) { value in
                    ChipView(value: value, isEnabled: currentBet + value <= bankroll) {
                        onChip(value)
                    }
                }
            }
            .padding(.horizontal, 30)

            Button("Clear Bet", action: onClear)
                .font(.footnote.weight(.bold))
                .foregroundStyle(.white.opacity(currentBet > 0 ? 0.85 : 0.3))
                .disabled(currentBet == 0)
        }
    }
}

#Preview("Betting") {
    BettingView(currentBet: 70, bankroll: 150, onChip: { _ in }, onClear: {})
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Theme.felt)
}
