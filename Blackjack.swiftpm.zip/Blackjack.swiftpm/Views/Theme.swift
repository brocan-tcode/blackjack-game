import SwiftUI

/// Every color and a couple of shared metrics live here, so the whole table
/// can be re-skinned from one file.
enum Theme {

    // MARK: Accents

    /// Gold used for labels, borders and primary buttons.
    static let gold = Color(red: 0.87, green: 0.70, blue: 0.26)

    static let win  = Color(red: 0.45, green: 0.90, blue: 0.50)
    static let loss = Color(red: 1.00, green: 0.50, blue: 0.45)

    static let hit   = Color.blue
    static let stand = Color.red
    static let split = Color(red: 0.55, green: 0.32, blue: 0.75)

    // MARK: Table

    /// Dark green felt with a subtle radial highlight, like a spotlight
    /// over the middle of the table.
    static var felt: RadialGradient {
        RadialGradient(
            colors: [
                Color(red: 0.10, green: 0.45, blue: 0.22),
                Color(red: 0.03, green: 0.24, blue: 0.11)
            ],
            center: .center,
            startRadius: 40,
            endRadius: 520
        )
    }

    // MARK: Cards

    static let cardSize = CGSize(width: 74, height: 106)
    static let cardCornerRadius: CGFloat = 10
    /// Blue panel on the back of a face-down card.
    static let cardBack = Color(red: 0.13, green: 0.25, blue: 0.55)

    // MARK: Chips

    /// Casino-style denominations: light 10, blue 20, red 50, black 100,
    /// purple 200, gold 500.
    static func chipColor(for value: Int) -> Color {
        switch value {
        case 10:  return Color(white: 0.92)
        case 20:  return Color(red: 0.20, green: 0.45, blue: 0.85)
        case 50:  return Color(red: 0.80, green: 0.22, blue: 0.22)
        case 100: return Color(white: 0.15)
        case 200: return Color(red: 0.55, green: 0.30, blue: 0.75)
        default:  return gold
        }
    }

    /// The pale $10 chip needs dark text and a gray rim; the rest use white.
    static func chipInkColor(for value: Int) -> Color { value == 10 ? .black : .white }
    static func chipRimColor(for value: Int) -> Color { value == 10 ? Color(white: 0.55) : .white }
}
