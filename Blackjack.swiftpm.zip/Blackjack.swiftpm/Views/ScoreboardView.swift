import SwiftUI

/// The slim status bar at the very top: bankroll · rounds played · session net.
struct ScoreboardView: View {
    let bankroll: Int
    let roundsPlayed: Int
    let netProfit: Int

    var body: some View {
        HStack(spacing: 0) {
            stat("BANKROLL", "$\(bankroll.formatted())", .white)
            divider
            stat("ROUNDS", "\(roundsPlayed)", .white)
            divider
            stat("NET", netText, netColor)
        }
        .padding(.vertical, 8)
        .background(RoundedRectangle(cornerRadius: 14).fill(.black.opacity(0.3)))
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .strokeBorder(Theme.gold.opacity(0.45), lineWidth: 1)
        )
    }

    private func stat(_ label: String, _ value: String, _ color: Color) -> some View {
        VStack(spacing: 2) {
            Text(label)
                .font(.system(size: 10, weight: .heavy))
                .tracking(1.5)
                .foregroundStyle(Theme.gold)
            Text(value)
                .font(.callout.weight(.bold))
                .monospacedDigit()
                .foregroundStyle(color)
                .contentTransition(.numericText())   // digits roll when they change
        }
        .frame(maxWidth: .infinity)
    }

    private var divider: some View {
        Rectangle()
            .fill(Theme.gold.opacity(0.35))
            .frame(width: 1, height: 26)
    }

    private var netText: String {
        if netProfit > 0 { return "+$\(netProfit.formatted())" }
        if netProfit < 0 { return "−$\((-netProfit).formatted())" }
        return "$0"
    }

    private var netColor: Color {
        if netProfit > 0 { return Theme.win }
        if netProfit < 0 { return Theme.loss }
        return .white
    }
}

#Preview("Scoreboard states") {
    VStack(spacing: 16) {
        ScoreboardView(bankroll: 1_000, roundsPlayed: 0, netProfit: 0)
        ScoreboardView(bankroll: 1_450, roundsPlayed: 12, netProfit: 450)
        ScoreboardView(bankroll: 620, roundsPlayed: 27, netProfit: -380)
    }
    .padding()
    .background(Theme.felt)
}
