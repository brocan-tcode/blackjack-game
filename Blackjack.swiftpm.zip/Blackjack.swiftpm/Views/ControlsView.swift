import SwiftUI

/// Large pill-shaped button used for every table action.
struct ActionButton: View {
    let title: String
    let color: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.title3.weight(.heavy))
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.6)   // "Play Again"/"Rebuy" shrink rather than wrap
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(Capsule().fill(color))
                .overlay(Capsule().strokeBorder(.white.opacity(0.35), lineWidth: 1))
                .shadow(color: .black.opacity(0.3), radius: 5, y: 3)
        }
        .buttonStyle(.plain)
    }
}

/// The bottom button row. Which buttons exist is driven entirely by the phase:
///
///     .betting    → Deal (or Rebuy when broke)
///     .playerTurn → Hit · Stand (· Split when the pair allows it)
///     .roundOver  → New Round (or Rebuy)
///
/// During `.dealing` / `.dealerTurn` the play buttons stay on screen but are
/// disabled and dimmed, so the layout never jumps while cards animate.
struct ControlsView: View {
    @ObservedObject var game: BlackjackViewModel

    var body: some View {
        Group {
            switch game.phase {
            case .betting:
                if game.isBroke {
                    ActionButton(title: "Rebuy $1,000", color: Theme.gold) { game.rebuy() }
                } else {
                    ActionButton(title: "Deal", color: Theme.gold) { game.deal() }
                        .disabled(game.currentBet == 0)
                        .opacity(game.currentBet == 0 ? 0.5 : 1)
                }

            case .roundOver:
                if game.isBroke {
                    ActionButton(title: "Rebuy $1,000", color: Theme.gold) { game.rebuy() }
                } else {
                    ActionButton(title: "New Round", color: Theme.gold) { game.nextRound() }
                }

            default:
                HStack(spacing: 12) {
                    ActionButton(title: "Hit", color: Theme.hit) { game.hit() }
                    ActionButton(title: "Stand", color: Theme.stand) { game.stand() }
                    if game.canSplit {
                        ActionButton(title: "Split", color: Theme.split) { game.split() }
                            .transition(.scale(scale: 0.7).combined(with: .opacity))
                    }
                }
                .disabled(game.phase != .playerTurn)
                .opacity(game.phase != .playerTurn ? 0.5 : 1)
            }
        }
        .animation(.spring(response: 0.35, dampingFraction: 0.8), value: game.phase)
        .animation(.spring(response: 0.35, dampingFraction: 0.8), value: game.canSplit)
    }
}

#Preview("Buttons") {
    VStack(spacing: 14) {
        ActionButton(title: "Deal", color: Theme.gold) {}
        HStack(spacing: 12) {
            ActionButton(title: "Hit", color: Theme.hit) {}
            ActionButton(title: "Stand", color: Theme.stand) {}
            ActionButton(title: "Split", color: Theme.split) {}
        }
    }
    .padding()
    .background(Theme.felt)
}
