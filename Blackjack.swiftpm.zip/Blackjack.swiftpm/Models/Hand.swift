import Foundation

// MARK: - Hand valuation

/// Best legal blackjack total for a hand.
///
/// Every ace is first counted as 11. While the total is over 21 and there is
/// still an ace counted as 11, one ace is demoted to 1 (subtract 10). This
/// yields the highest total that does not bust, which is exactly the casino rule.
///
///     A + 9      → 20   (ace stays 11)
///     A + 9 + 5  → 15   (ace demoted to 1)
///     A + A + 9  → 21   (one ace 11, one ace 1)
func handValue(of hand: [Card]) -> Int {
    var total = hand.reduce(0) { $0 + $1.rank.value }
    var flexibleAces = hand.filter { $0.rank == .ace }.count
    while total > 21 && flexibleAces > 0 {
        total -= 10          // demote one ace from 11 to 1
        flexibleAces -= 1
    }
    return total
}

// MARK: - Outcome

/// How a single hand settled. Drives both the payout and the badge shown
/// under a split hand.
enum HandOutcome: String {
    case blackjack = "Blackjack!"
    case win       = "Win"
    case push      = "Push"
    case lose      = "Lose"
    case bust      = "Bust"

    /// True for outcomes that paid the player — used to color the badge.
    var isFavorable: Bool { self == .win || self == .blackjack }
}

// MARK: - PlayerHand

/// One of the player's hands. Usually there is exactly one; after a split
/// there are two, each carrying its own bet and played in sequence.
struct PlayerHand: Identifiable {
    let id = UUID()
    var cards: [Card] = []
    var bet: Int
    /// Set once the hand stood, busted or hit 21 — the round advances past it.
    var isFinished = false
    /// Filled in at settlement.
    var outcome: HandOutcome?

    var score: Int { handValue(of: cards) }
    var isBusted: Bool { score > 21 }

    /// A "natural" — 21 on the opening two cards, which pays 3:2.
    /// Split hands never qualify, so the caller passes `isSplit`.
    func isNaturalBlackjack(isSplit: Bool) -> Bool {
        !isSplit && cards.count == 2 && score == 21
    }
}
