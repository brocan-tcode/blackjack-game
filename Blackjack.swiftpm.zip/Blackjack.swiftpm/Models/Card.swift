import SwiftUI

// MARK: - Suit

/// The four suits. The raw value is the symbol drawn on the card face.
enum Suit: String, CaseIterable {
    case hearts   = "♥"
    case diamonds = "♦"
    case clubs    = "♣"
    case spades   = "♠"

    /// Hearts/diamonds render red, clubs/spades render black — like a real deck.
    var color: Color {
        switch self {
        case .hearts, .diamonds: return .red
        case .clubs, .spades:    return .black
        }
    }
}

// MARK: - Rank

/// 2–10 plus the face cards and ace. The raw value of 2–10 is the pip count.
enum Rank: Int, CaseIterable {
    case two = 2, three, four, five, six, seven, eight, nine, ten
    case jack, queen, king, ace

    /// Text shown in the card corners ("2"…"10", "J", "Q", "K", "A").
    var label: String {
        switch self {
        case .jack:  return "J"
        case .queen: return "Q"
        case .king:  return "K"
        case .ace:   return "A"
        default:     return String(rawValue)
        }
    }

    /// Blackjack value. Aces start at 11 and are demoted to 1 by
    /// `handValue(of:)` whenever counting them as 11 would bust the hand.
    var value: Int {
        switch self {
        case .jack, .queen, .king: return 10
        case .ace:                 return 11
        default:                   return rawValue
        }
    }
}

// MARK: - Card

struct Card: Identifiable, Equatable {
    /// Stable identity so SwiftUI can animate each card individually.
    let id = UUID()
    let suit: Suit
    let rank: Rank
    /// `false` only for the dealer's hole card, until it is revealed.
    var isFaceUp = true
}
