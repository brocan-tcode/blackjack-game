import Foundation

/// A shuffled 52-card deck.
///
/// * `draw` **removes** the card from the deck, so duplicates are impossible.
/// * When the deck runs low it automatically rebuilds a fresh 52-card deck,
///   minus any cards still on the table, and reshuffles.
/// * `shuffled()` uses `SystemRandomNumberGenerator` (cryptographically
///   seeded), so the order is strongly random.
struct Deck {
    private(set) var cards: [Card] = []

    /// Reshuffle once the shoe gets this low.
    static let reshuffleThreshold = 10

    init() { rebuild() }

    var count: Int { cards.count }

    /// Builds a fresh 52-card deck, removes one copy of every card currently
    /// in play (so the table never shows two Kings of Spades), and shuffles.
    mutating func rebuild(excluding inPlay: [Card] = []) {
        var fresh = Suit.allCases.flatMap { suit in
            Rank.allCases.map { rank in Card(suit: suit, rank: rank) }
        }
        for used in inPlay {
            if let i = fresh.firstIndex(where: { $0.suit == used.suit && $0.rank == used.rank }) {
                fresh.remove(at: i)
            }
        }
        cards = fresh.shuffled()
    }

    /// Removes and returns the top card. If the deck has run low it is rebuilt
    /// first — never duplicating the cards passed in `keeping`, which is why
    /// callers hand over every card currently visible on the table.
    mutating func draw(faceUp: Bool = true, keeping inPlay: [Card] = []) -> Card {
        if cards.count <= Self.reshuffleThreshold {
            rebuild(excluding: inPlay)
        }
        var card = cards.removeLast()
        card.isFaceUp = faceUp
        return card
    }
}
