import SwiftUI

// MARK: - Game phase

/// The round state machine:
///
///     betting ──deal()──▶ dealing ──▶ playerTurn ──stand/bust──▶ dealerTurn
///        ▲                   │            │  ▲                        │
///        │                   │ natural    │  │ split() / next          │
///        │                   ▼ blackjack  ▼  │ split hand              ▼
///        └──nextRound()── roundOver ◀──────┴──────────────── settleRound()
///
/// `.dealing` doubles as a "busy" phase whenever cards are animating and taps
/// must be ignored (initial deal, split transition, moving between hands).
enum GamePhase {
    case betting     // chips visible, building a bet
    case dealing     // cards animating — input blocked
    case playerTurn  // Hit / Stand (/ Split) live for the active hand
    case dealerTurn  // dealer revealing + drawing to 17
    case roundOver   // payouts done, New Round available
}

// MARK: - View model

/// Owns all game state and rules. Views only read published properties and
/// call the intent methods (`addChip`, `deal`, `hit`, `stand`, `split`, …).
@MainActor
final class BlackjackViewModel: ObservableObject {

    // MARK: Configuration

    static let chipValues = [10, 20, 50, 100, 200, 500]
    static let startingBankroll = 1_000
    static let dealerStandsOn = 17
    /// Below the cheapest chip the player can no longer bet — time to rebuy.
    static var minimumBet: Int { chipValues.min() ?? 10 }

    // MARK: Published state (the UI re-renders whenever these change)

    @Published private(set) var bankroll = BlackjackViewModel.startingBankroll
    @Published private(set) var currentBet = 0            // being built during .betting
    @Published private(set) var playerHands: [PlayerHand] = []
    @Published private(set) var activeHandIndex = 0       // which hand Hit/Stand applies to
    @Published private(set) var dealerHand: [Card] = []
    @Published private(set) var phase: GamePhase = .betting
    @Published private(set) var statusMessage = "Place Your Bet"

    // Scoreboard
    @Published private(set) var roundsPlayed = 0
    /// Bankroll relative to every dollar bought in. Updated only at settlement
    /// (and rebuy) so the scoreboard doesn't twitch while money is on the table.
    @Published private(set) var netSessionProfit = 0

    private var deck = Deck()
    private var totalBuyIns = BlackjackViewModel.startingBankroll

    // MARK: Derived state

    var dealerScore: Int { handValue(of: dealerHand) }
    var holeCardHidden: Bool { dealerHand.contains { !$0.isFaceUp } }

    /// While the hole card is face down only the face-up cards are counted,
    /// so the hidden value never leaks into the UI.
    var dealerVisibleScore: Int { handValue(of: dealerHand.filter(\.isFaceUp)) }

    var isSplit: Bool { playerHands.count > 1 }
    var isBroke: Bool { bankroll < Self.minimumBet }

    /// Split is offered only on the opening two cards of an un-split hand,
    /// when both cards share a rank and the bankroll can cover a second bet.
    var canSplit: Bool {
        phase == .playerTurn
            && playerHands.count == 1
            && playerHands[0].cards.count == 2
            && playerHands[0].cards[0].rank == playerHands[0].cards[1].rank
            && bankroll >= playerHands[0].bet
    }

    /// Every card currently on the table — handed to the deck so a low-deck
    /// reshuffle can never mint a duplicate of a visible card.
    private var tableCards: [Card] { playerHands.flatMap(\.cards) + dealerHand }

    // MARK: - Betting phase

    /// Tapping a chip stacks it onto the bet — but never past the bankroll.
    func addChip(_ value: Int) {
        guard phase == .betting, currentBet + value <= bankroll else { return }
        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) { currentBet += value }
    }

    func clearBet() {
        guard phase == .betting else { return }
        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) { currentBet = 0 }
    }

    /// Locks the bet in: money leaves the bankroll here and only returns via
    /// payouts in `settleRound`. State: `.betting` → `.dealing`.
    func deal() {
        guard phase == .betting, currentBet > 0, currentBet <= bankroll else { return }
        withAnimation(.easeInOut(duration: 0.3)) { phase = .dealing }
        bankroll -= currentBet
        roundsPlayed += 1
        Task { await dealInitialCards() }
    }

    /// When the bankroll can't cover the smallest chip the game is over — this
    /// tops the player back up, and the scoreboard keeps counting the buy-in.
    func rebuy() {
        guard isBroke, phase == .betting || phase == .roundOver else { return }
        withAnimation { bankroll += Self.startingBankroll }
        totalBuyIns += Self.startingBankroll
        netSessionProfit = bankroll - totalBuyIns
        if phase == .roundOver { nextRound() }
    }

    /// State: `.roundOver` → `.betting`, with a clean table.
    func nextRound() {
        guard phase == .roundOver else { return }
        withAnimation(.easeOut(duration: 0.35)) {
            playerHands = []
            dealerHand = []
            currentBet = 0
            activeHandIndex = 0
            phase = .betting
            statusMessage = "Place Your Bet"
        }
    }

    // MARK: - Initial deal

    private func dealInitialCards() async {
        withAnimation(.easeOut(duration: 0.25)) {
            dealerHand = []
            playerHands = [PlayerHand(bet: currentBet)]   // one hand until a split
            activeHandIndex = 0
        }
        setStatus("Dealing…")
        await pause(0.4)

        // Casino order: player, dealer (up), player, dealer (down — the hole card).
        // The pauses stagger the deal so each card slides in on its own.
        dealCard(toHand: 0)
        await pause(0.35)
        dealDealerCard(faceUp: true)
        await pause(0.35)
        dealCard(toHand: 0)
        await pause(0.35)
        dealDealerCard(faceUp: false)
        await pause(0.5)

        if playerHands[0].score == 21 {
            // A natural blackjack — reveal the hole card and settle immediately
            // (pays 3:2 in settleRound unless the dealer also has one).
            playerHands[0].isFinished = true
            await revealHoleCard()
            settleRound()
        } else {
            withAnimation { phase = .playerTurn }
            setStatus("Hit or Stand?")
        }
    }

    // MARK: - Player actions

    func hit() {
        guard phase == .playerTurn else { return }
        dealCard(toHand: activeHandIndex)

        let score = playerHands[activeHandIndex].score
        if score > 21 {
            // Bust: finish this hand and block input while the transition to
            // the next hand (or the dealer) plays out.
            playerHands[activeHandIndex].isFinished = true
            phase = .dealing
            Task { await advanceAfterHandFinished(busted: true) }
        } else if score == 21 {
            stand()   // hitting on 21 can only lose — stand automatically
        }
    }

    func stand() {
        guard phase == .playerTurn else { return }
        playerHands[activeHandIndex].isFinished = true
        phase = .dealing          // block input during the transition
        Task { await advanceAfterHandFinished(busted: false) }
    }

    /// Splits the opening pair into two hands. State changes:
    /// * a second bet (equal to the first) leaves the bankroll,
    /// * the pair is torn apart — one card per hand,
    /// * hand 1 immediately receives its second card and play continues on it;
    ///   hand 2 waits (holding one card) until hand 1 finishes.
    func split() {
        guard canSplit else { return }
        let bet = playerHands[0].bet
        bankroll -= bet
        phase = .dealing          // block input while the split animates

        withAnimation(.spring(response: 0.45, dampingFraction: 0.75)) {
            let movedCard = playerHands[0].cards.removeLast()
            playerHands.append(PlayerHand(cards: [movedCard], bet: bet))
        }

        Task {
            await pause(0.5)
            dealCard(toHand: 0)                   // hand 1's replacement card
            await pause(0.45)
            withAnimation { phase = .playerTurn }
            setStatus("Hand 1: Hit or Stand?")
            if playerHands[0].score == 21 { stand() }   // e.g. split aces + a ten
        }
    }

    // MARK: - Hand-to-hand / dealer transition

    /// Runs after the active hand finishes. Either activates the next split
    /// hand (dealing it its second card) or hands control to the dealer.
    private func advanceAfterHandFinished(busted: Bool) async {
        if busted {
            setStatus(isSplit ? "Hand \(activeHandIndex + 1) Busts!" : "Bust!")
            await pause(0.7)
        }

        if let next = playerHands.firstIndex(where: { !$0.isFinished }) {
            // State: .dealing → .playerTurn for the next split hand.
            withAnimation(.spring(response: 0.4, dampingFraction: 0.75)) { activeHandIndex = next }
            await pause(0.35)
            if playerHands[next].cards.count == 1 {
                dealCard(toHand: next)            // the waiting hand gets its second card
                await pause(0.45)
            }
            withAnimation { phase = .playerTurn }
            setStatus("Hand \(next + 1): Hit or Stand?")
            if playerHands[next].score == 21 { stand() }
        } else {
            await playDealerTurn()
        }
    }

    // MARK: - Dealer AI

    /// Standard casino rules: reveal the hole card, then — if any player hand
    /// is still live — hit until the dealer totals 17 or more, then settle.
    private func playDealerTurn() async {
        withAnimation { phase = .dealerTurn }
        setStatus("Dealer's Turn…")
        await revealHoleCard()

        let anyLiveHand = playerHands.contains { !$0.isBusted }
        if anyLiveHand {
            while dealerScore < Self.dealerStandsOn {
                await pause(0.8)                  // dramatic pause between draws
                dealDealerCard(faceUp: true)
            }
        }
        await pause(0.6)
        settleRound()
    }

    // MARK: - Settlement

    /// Pays every hand and moves to `.roundOver`. Payout rules:
    /// * natural blackjack (un-split, first two cards) — 3:2, push vs a dealer natural
    /// * win — 1:1 · push — bet returned · bust/lose — the bet is already gone.
    private func settleRound() {
        let dealer = dealerScore
        let dealerBlackjack = dealerHand.count == 2 && dealer == 21
        var returned = 0

        for i in playerHands.indices {
            let hand = playerHands[i]

            if hand.isBusted {
                playerHands[i].outcome = .bust
            } else if hand.isNaturalBlackjack(isSplit: isSplit) {
                if dealerBlackjack {
                    returned += hand.bet                        // push — bet back
                    playerHands[i].outcome = .push
                } else {
                    returned += hand.bet + hand.bet * 3 / 2     // 3:2 payout + stake
                    playerHands[i].outcome = .blackjack
                }
            } else if dealer > 21 || hand.score > dealer {
                returned += hand.bet * 2                        // 1:1 payout + stake
                playerHands[i].outcome = .win
            } else if hand.score < dealer {
                playerHands[i].outcome = .lose
            } else {
                returned += hand.bet                            // push — bet back
                playerHands[i].outcome = .push
            }
        }

        withAnimation { bankroll += returned }
        netSessionProfit = bankroll - totalBuyIns

        let wagered = playerHands.reduce(0) { $0 + $1.bet }
        finishRound(message: roundMessage(net: returned - wagered,
                                          wagered: wagered,
                                          dealerBusted: dealer > 21))
    }

    private func roundMessage(net: Int, wagered: Int, dealerBusted: Bool) -> String {
        if playerHands.count == 1 {
            switch playerHands[0].outcome {
            case .blackjack: return "Blackjack! +$\(net)"
            case .win:       return dealerBusted ? "Dealer Busts! +$\(net)" : "You Win! +$\(net)"
            case .bust:      return "Bust! −$\(wagered)"
            case .lose:      return "Dealer Wins −$\(wagered)"
            default:         return "Push — Bet Returned"
            }
        }
        // Split summary, e.g. "Win · Bust  (±$0)"
        let sign = net > 0 ? "+$\(net)" : (net < 0 ? "−$\(-net)" : "±$0")
        let parts = playerHands.compactMap(\.outcome).map(\.rawValue).joined(separator: " · ")
        return "\(parts)  (\(sign))"
    }

    // MARK: - Helpers

    private func dealCard(toHand index: Int) {
        let card = deck.draw(keeping: tableCards)
        withAnimation(.spring(response: 0.45, dampingFraction: 0.75)) {
            playerHands[index].cards.append(card)
        }
    }

    private func dealDealerCard(faceUp: Bool) {
        let card = deck.draw(faceUp: faceUp, keeping: tableCards)
        withAnimation(.spring(response: 0.45, dampingFraction: 0.75)) {
            dealerHand.append(card)
        }
    }

    /// Flips the dealer's face-down card. Because `CardView` rotates on
    /// `isFaceUp`, wrapping the mutation in `withAnimation` produces the 3D flip.
    private func revealHoleCard() async {
        guard let i = dealerHand.firstIndex(where: { !$0.isFaceUp }) else { return }
        withAnimation(.easeInOut(duration: 0.5)) {
            dealerHand[i].isFaceUp = true
        }
        await pause(0.6)
    }

    private func finishRound(message: String) {
        withAnimation(.spring(response: 0.4, dampingFraction: 0.7)) {
            phase = .roundOver
            statusMessage = message
        }
    }

    private func setStatus(_ message: String) {
        withAnimation(.easeInOut(duration: 0.25)) {
            statusMessage = message
        }
    }

    private func pause(_ seconds: Double) async {
        try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
    }
}
