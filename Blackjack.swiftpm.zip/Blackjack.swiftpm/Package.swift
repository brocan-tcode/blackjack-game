// swift-tools-version: 5.9

import PackageDescription
import AppleProductTypes

// This is an Xcode App Playground: no .xcodeproj to maintain, and every .swift
// file in the folders below is compiled automatically.
//
// It runs in the iOS Simulator with no configuration at all.
//
// To run on a physical iPhone you need your own Apple development team, which
// is personal, so this repo ships without one. See README → "Run on a real
// iPhone": either pick your team in Xcode's signing editor, or set the two
// values below locally (and leave that change uncommitted).

let package = Package(
    name: "Blackjack",
    platforms: [
        .iOS("17.0")
    ],
    products: [
        .iOSApplication(
            name: "Blackjack",
            targets: ["AppModule"],
            bundleIdentifier: "com.example.blackjack",   // ← your bundle ID, for device builds
            teamIdentifier: "",                          // ← your 10-character team ID
            displayVersion: "1.1",
            bundleVersion: "1",
            appIcon: .placeholder(icon: .twoPeople),
            accentColor: .presetColor(.green),
            supportedDeviceFamilies: [
                .phone,
                .pad
            ],
            supportedInterfaceOrientations: [
                .portrait
            ]
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: "."
        )
    ]
)
